const display = document.getElementById("display");
let currentInput = "";

// Update display
function updateDisplay(value) {
    display.textContent = value || "0";
}

// Evaluate expression safely
function calculate(expr) {
    try {
        return Function("return " + expr)();
    } catch {
        return "Error";
    }
}

// Handle button clicks
document.querySelectorAll("button").forEach(btn => {
    btn.addEventListener("click", () => {
        const value = btn.textContent;

        if (value === "C") {
            currentInput = "";
            updateDisplay(currentInput);
        } else if (value === "=") {
            currentInput = calculate(
                currentInput.replace(/×/g, "*").replace(/÷/g, "/")
            ).toString();
            updateDisplay(currentInput);
        } else {
            currentInput += value;
            updateDisplay(currentInput);
        }
    });
});

// Keyboard support
document.addEventListener("keydown", (e) => {
    const key = e.key;

    if (!isNaN(key) || "+-*/.".includes(key)) {
        currentInput += key.replace("*", "×").replace("/", "÷");
        updateDisplay(currentInput);
    } else if (key === "Enter") {
        currentInput = calculate(
            currentInput.replace(/×/g, "*").replace(/÷/g, "/")
        ).toString();
        updateDisplay(currentInput);
    } else if (key === "Backspace") {
        currentInput = currentInput.slice(0, -1);
        updateDisplay(currentInput);
    } else if (key.toLowerCase() === "c") {
        currentInput = "";
        updateDisplay(currentInput);
    }
});